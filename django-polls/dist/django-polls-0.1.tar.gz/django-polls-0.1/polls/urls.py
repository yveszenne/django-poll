from django.urls import path

from . import views

app_name = "polls"

urlpatterns = [
    #/polls/
    path("", views.IndexView.as_view(), name="index"),
    #/polls/3/
    path("<int:pk>/", views.DetailView.as_view(), name="detail"),
    #/polls/3/results/
    path("<int:pk>/results/", views.ResultsView.as_view(), name="results"),
    #/polls/3/vote/
    path("<int:pk>/vote/", views.vote, name="vote"),
    #main
]